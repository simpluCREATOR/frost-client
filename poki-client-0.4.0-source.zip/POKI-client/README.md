# POKI Client 0.4.0 — Minecraft 1.21.11

Client-side Fabric utilities for an Apple Silicon Mac. The original mod ID `aurora` and `config/aurora.json` remain unchanged so existing module settings survive the upgrade.

## Updates in 0.4.0

- Dark Mode now themes vanilla menu buttons/backgrounds and inventory/container panels, including creative tabs. Inventory headings brighten for readability; switching OFF restores original UI colors without a resource reload.
- **Right Shift → HUD** opens a drag editor for Keystrokes, Coordinates and FPS. Positions save when you release a drag or close the editor. Arrow keys nudge the selected widget; Shift-arrows move ten pixels. Reset restores only HUD placement. Disabled HUD elements remain available as marked previews in the editor.
- Placement is independent per widget and stays within the display when resolution or GUI scale changes. Existing module, fire, shield and theme settings carry over.

## Previous fire crash fix retained

Fixes the crash when selecting Low fire while burning. Minecraft 1.21.11's atlas manager distinguishes atlas definition IDs from texture paths. The low-fire hook now resolves a Material through the correct API and falls back to the original fire sprite if the bundled sprite is missing. Existing settings do not need to be reset.

## What's new

- **Keystrokes:** W above A/S/D, then two wider LMB/RMB tiles, then one full-width spacebar underneath. The space symbol is drawn directly, so it cannot turn into a missing font glyph.
- **Modern Right Shift menu:** custom rounded cards, toggle switches, smooth Inter typography, purple accents, and Modules / Visuals / Settings / HUD tabs. No vanilla gray button textures are used for the POKI menu. This is an original interface inspired by the modern client style, not a copy of Lunar artwork.
- **Visuals → Fire:** click to cycle Default → Low → None. New installations start on Low. Default preserves the active resource pack's normal fire overlay. Low uses bundled low-fire PNGs. None hides the first-person fire overlay. World fire, other burning entities and fire damage are unchanged.
- **Visuals → Low Shield:** ON/OFF. Lowers the first-person shield in either hand, including while blocking. Other held items and blocking mechanics are unchanged. Defaults OFF.
- **Settings → Dark Mode:** ON/OFF. Switches the POKI menu/HUD and supported vanilla menus/containers between dark and light themes immediately, and saves the choice. Defaults ON. Custom mod-specific UI skins keep their own styling.
- **Settings → GUI Scale / VSync:** the previous controls remain available. They change real Minecraft settings, saved to `options.txt`.

The low-fire PNGs are from **Low Fire by alexin1337**, whose project declares MIT licensing. They are bundled under POKI's own texture namespace with attribution and license text. The original resource pack's block models and vanilla texture replacements are not installed. Inter is bundled under SIL OFL 1.1. See THIRD-PARTY-NOTICES.md.

## Install in Modrinth

1. Use a **Minecraft 1.21.11 release / Fabric** profile with **Java 21**, Fabric Loader **0.20.1**, and Fabric API **0.141.6+1.21.11**.
2. Replace the previous POKI/Aurora JAR with **one** 0.4.0 edition. Do not keep the old client JAR alongside the new one.
3. The **Vulkan edition** includes unchanged VulkanMod 0.6.8+1.21.11 and its Apple Silicon/MoltenVK libraries. Do not install another VulkanMod, Sodium or Iris alongside it. The Vulkan build declares Sodium/Iris conflicts so Fabric can explain the conflict before loading.
4. The **OpenGL fallback** has the same POKI interface, textures and visual settings without a bundled renderer. To return to vanilla OpenGL, remove a separately installed VulkanMod too.
5. Enter a world and press **Right Shift**. Choose Visuals for Fire and Low Shield, or Settings for Dark Mode, GUI Scale and VSync. Use HUD to move the HUD elements, then Done to return to the menu. Escape, Right Shift or × closes the menu.

The source ZIP is for editing/building, not for the `mods` folder. Both production editions need Fabric API. Renderer changes require quitting Minecraft and replacing the JAR; there is no hot renderer switch.

## Existing modules

Auto Sprint and Fullbright default OFF. Zoom, FPS, Coordinates and Keystrokes default ON. Hold C to zoom; change its binding in Minecraft Controls. F1 hides the HUD. The menu does not pause gameplay.

Fullbright changes lightmap inputs without changing potion effects or saved gamma. Zoom changes returned FOV without changing saved FOV. Low Fire/Low Shield are visual changes, not game-mechanic changes. These hooks target 1.21.11 specifically.

## Build

```sh
./mac.sh build                         # Vulkan edition (default)
./mac.sh runClient                     # Separate development instance
./mac.sh build -PbundleVulkan=false    # OpenGL fallback
./mac.sh runClient -PbundleVulkan=false
```

The helper selects the project-local ARM64 Temurin Java 21, then a system ARM64 JDK 21 if the project has been moved. Select JDK 21 as both your project SDK and Gradle JVM in an IDE. Production JARs are in `build/libs/`; do not install the `-sources.jar`.

Pinned: Minecraft 1.21.11, Loader 0.20.1, Fabric API 0.141.6+1.21.11, Loom 1.14.10, Gradle 9.2.1 and Java 21. The Gradle distribution checksum remains pinned. VulkanMod's unchanged upstream JAR is provided in `libs/` for reproducible local builds.

## Source layout

- `AuroraClient.java`: client entry point, keybindings, lifecycle and HUD registration.
- `module/ModuleManager.java`: module toggles, Fire mode, Low Shield, Dark Mode saved normalized HUD positions and backward-compatible config loading/saving.
- `gui/ClickGuiScreen.java`: responsive tab layout and controls; `ModernButton.java` draws custom widgets while retaining keyboard/focus/narration support; `UiTheme.java` provides colors, rounded shapes and Inter text.
- `hud/ClientHud.java`: independent widget bounds and themed FPS/coordinates/keystrokes drawing. `HudLayout.java` stores normalized positions; `gui/HudEditorScreen.java` handles dragging, nudging, preview and Reset.
- `gui/VanillaDarkTheme.java` and `mixin/GuiGraphicsMixin.java`: targeted vanilla UI texture modulation and readable container labels, using renderer-neutral drawing APIs.
- `mixin/ScreenEffectRendererMixin.java`: chooses the fire overlay mode and PNG sprite.
- `mixin/ItemInHandRendererMixin.java`: balanced shield-only pose adjustment.
- Other `mixin/` files: existing FOV and Fullbright hooks.
- `src/main/resources/assets/`: POKI font, low-fire PNGs, additive atlas entries and keybinding names.
- `build.gradle`, `gradle.properties`, `gradle/wrapper/`, `mac.sh`: versions, renderer packaging, Java selection and build entry points.

See VERIFICATION.md for completed checks and SMOKE-TEST.md for remaining in-world/UI checks. No FPS increase is claimed as measured.

## Targeted regression test

The opt-in test launches actual Minecraft, waits for real atlas loading, reproduces the old invalid-atlas call, then invokes the mixin-transformed fire renderer 90 times across Default / Low / None. It also inspects actual GuiGraphics drawing states for inventory/button/tab dark colors, label readability, restoration and preserved item colors. HUD event tests enter through the real menu tab, drag all three elements, reload saved positions, clamp to edges, resize, nudge, draw the preview, and reset. It checks emitted sprite UVs and verifies None cancels geometry. A recording vertex consumer avoids drawing extra test geometry; no world or GUI clicks are needed. The test exits the development instance automatically and is excluded from production JARs.

```sh
./mac.sh runClient -PpokiRegression=true
./mac.sh runClient -PpokiRegression=true -PbundleVulkan=false
```

Test files and settings are isolated under `run-regression/`.
