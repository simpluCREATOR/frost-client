# POKI 0.4.0 verification — 2026-10-27

## New behavior

Dark Mode now modulates supported vanilla GUI backgrounds and controls at draw time. It includes raw container panels, menu backgrounds, standard buttons/sliders/text fields, and creative inventory tabs. Standard dark inventory headings become light gray. The toggle restores original drawing colors immediately when OFF. POKI's own menu/HUD themes continue to work. Item/world texture paths are excluded; custom mod-specific UI skins are outside this targeted vanilla coverage.

Right Shift → HUD opens a dedicated editor for FPS, Coordinates and Keystrokes. Rendering and hit testing share the same bounds. Drag-release, close and reset save normalized positions in the existing aurora.json config. Positions are independent, clamped and adapted to resolution/GUI-scale changes. The editor previews disabled widgets without enabling them. Existing settings and the prior fire crash fix are preserved.

## Completed checks

**Both real Minecraft 1.21.11 renderer launches passed the same integration suite on the Apple M1 / Java 21 toolchain:**

- Actual mixin-transformed GuiGraphics recorded expected dark inventory texture colors, pause/options button colors and creative-tab colors. Nine-sliced buttons were tinted once.
- Actual inventory-label drawing recorded a readable light text color.
- Dark Mode OFF restored original inventory/button colors. Item-atlas drawing retained its original white modulation.
- The real HUD menu button opened HudEditorScreen. Event-handler tests dragged all three widgets and confirmed the gameplay renderer's shared bounds matched their new positions.
- New ModuleManager instances reloaded the saved positions. Dragging outside the canvas clamped to the edge; resizing retained visible placement; Shift-arrow nudged ten pixels; preview drawing and Reset completed.
- The previous actual fire-render regression still passed 90 calls per renderer across Default, Low and None.
- An isolated Java config-upgrade check using the current ModuleManager/HudLayout source passed legacy toggle retention, persistence, fire cycling, unknown-mode handling and malformed-config recovery. This uses a temporary config directory and a minimal FabricLoader stub; it does not modify a launcher profile.

Both normal production builds succeeded with ARM64 Java 21, Gradle 9.2.1 and Loom 1.14.10. Packaged JARs passed integrity, version/dependency metadata, all five mixins, Java 21 bytecode and asset checks. The bundled VulkanMod binary remains unchanged and SHA-512 verified. Development regression classes are excluded from production.

## Limits

Integration checks inspect real GUI drawing states and invoke widget event handlers in the actual game runtime. They do not compare final framebuffer screenshots, run a multiplayer session, or verify every third-party resource pack/mod GUI. Manual visual checks for the usual profile are in SMOKE-TEST.md. The renderer's existing terrain_earlyZ warnings and development Realms messages remain non-fatal in the passing tests. No FPS benchmark was performed.
