package dev.aurora.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.aurora.client.AuroraClient;
import dev.aurora.client.module.ModuleManager.FireMode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.Material;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Changes only the first-person overlay. World fire and damage remain vanilla. */
@Mixin(ScreenEffectRenderer.class)
public abstract class ScreenEffectRendererMixin {
    // Material takes the atlas TEXTURE location. AtlasManager#getAtlasOrThrow instead
    // takes a definition ID such as minecraft:blocks, not textures/atlas/blocks.png.
    private static final Material POKI_LOW_FIRE = new Material(TextureAtlas.LOCATION_BLOCKS,
        Identifier.fromNamespaceAndPath("aurora", "block/low_fire_1"));
    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void poki$hideFire(PoseStack pose, MultiBufferSource buffers, TextureAtlasSprite sprite, CallbackInfo ci) {
        if (AuroraClient.modules != null && AuroraClient.modules.fireMode() == FireMode.NONE) ci.cancel();
    }
    @ModifyVariable(method = "renderFire", at = @At("HEAD"), argsOnly = true)
    private static TextureAtlasSprite poki$lowFire(TextureAtlasSprite original) {
        if (AuroraClient.modules == null || AuroraClient.modules.fireMode() != FireMode.LOW) return original;
        TextureAtlasSprite low = Minecraft.getInstance().getAtlasManager().get(POKI_LOW_FIRE);
        // A missing/overridden resource should retain normal fire, not draw a missing sprite.
        return low != null && POKI_LOW_FIRE.texture().equals(low.contents().name()) ? low : original;
    }
}
