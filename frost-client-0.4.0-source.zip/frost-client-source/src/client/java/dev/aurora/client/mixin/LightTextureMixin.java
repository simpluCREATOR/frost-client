package dev.aurora.client.mixin;

import dev.aurora.client.AuroraClient;
import dev.aurora.client.module.Module;
import net.minecraft.client.renderer.LightTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * 1.21.11 lightmap UBO floats: ambient, sky, block, night vision, darkness,
 * world darkening, brightness. Ordinals verified against the release bytecode
 * and its lightmap.fsh. Re-check these hooks before changing Minecraft versions.
 * No potion effects or persisted brightness options are changed.
 */
@Mixin(LightTexture.class)
public abstract class LightTextureMixin {
    private static boolean aurora$fullbright() {
        return AuroraClient.modules != null && AuroraClient.modules.enabled(Module.FULLBRIGHT);
    }
    @ModifyArg(method = "updateLightTexture", at = @At(value = "INVOKE",
        target = "Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;",
        ordinal = 3), index = 0)
    private float aurora$nightVision(float original) {
        return aurora$fullbright() ? 1.0F : original;
    }
    @ModifyArg(method = "updateLightTexture", at = @At(value = "INVOKE",
        target = "Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;",
        ordinal = 4), index = 0)
    private float aurora$darkness(float original) {
        return aurora$fullbright() ? 0.0F : original;
    }
}
