package dev.aurora.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/** Custom drawing; vanilla widget behavior retains focus, keyboard and narration support. */
public final class ModernButton extends Button {
    private final String label;
    private final Supplier<String> value;
    private final BooleanSupplier selected;
    private final boolean toggle;
    private final boolean tab;

    public ModernButton(int x, int y, int w, int h, String label, Supplier<String> value,
        BooleanSupplier selected, boolean toggle, boolean tab, Runnable action) {
        super(x, y, w, h, UiTheme.text(label), button -> action.run(), DEFAULT_NARRATION);
        this.label = label; this.value = value; this.selected = selected; this.toggle = toggle; this.tab = tab;
    }
    @Override protected void renderContents(GuiGraphics g, int mouseX, int mouseY, float delta) {
        var font = Minecraft.getInstance().font;
        boolean on = selected.getAsBoolean();
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        String state = value.get();
        setMessage(UiTheme.text(label + (state.isEmpty() ? "" : ": " + state)));
        int bg = tab && on ? UiTheme.accentFill() : isHoveredOrFocused() ? UiTheme.hover() : UiTheme.card();
        UiTheme.round(g, x, y, w, h, 6, isFocused() ? UiTheme.accent() : UiTheme.border());
        UiTheme.round(g, x + 1, y + 1, w - 2, h - 2, 5, bg);
        int color = tab && on ? 0xFFFFFFFF : UiTheme.text();
        if (tab) {
            var text = UiTheme.text(label);
            g.drawString(font, text, x + (w - font.width(text)) / 2, y + (h - 9) / 2, color, false);
        } else {
            g.drawString(font, UiTheme.text(label), x + 10, y + (h - 9) / 2, color, false);
            if (toggle) {
                int tx = x + w - 33, ty = y + (h - 12) / 2;
                if (w >= 220) {
                    var stateText = UiTheme.text(state);
                    g.drawString(font, stateText, tx - font.width(stateText) - 8, y + (h - 9) / 2, UiTheme.muted(), false);
                }
                UiTheme.round(g, tx, ty, 24, 12, 6, on ? UiTheme.accentFill() : UiTheme.border());
                UiTheme.round(g, tx + (on ? 13 : 2), ty + 2, 8, 8, 4, 0xFFFFFFFF);
            } else {
                var text = UiTheme.text(state);
                int vw = font.width(text);
                UiTheme.round(g, x + w - vw - 20, y + (h - 17) / 2, vw + 12, 17, 5, UiTheme.hover());
                g.drawString(font, text, x + w - vw - 14, y + (h - 9) / 2, UiTheme.accent(), false);
            }
        }
    }
}
