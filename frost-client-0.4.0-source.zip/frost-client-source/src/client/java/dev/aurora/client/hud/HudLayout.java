package dev.aurora.client.hud;

import java.util.EnumMap;
import java.util.Map;

/** Normalized positions within the usable canvas keep widgets visible after a resize. */
public final class HudLayout {
    public enum Element {
        FPS("fps", "FPS", 8, 8), COORDINATES("coordinates", "Coordinates", 8, 26),
        KEYSTROKES("keystrokes", "Keystrokes", 8, 48);
        public final String id, label;
        public final int defaultX, defaultY;
        Element(String id, String label, int x, int y) { this.id = id; this.label = label; defaultX = x; defaultY = y; }
    }
    public record Anchor(double x, double y) {}
    public record Point(int x, int y) {}
    private final EnumMap<Element, Anchor> anchors = new EnumMap<>(Element.class);
    public Point position(Element element, int screenW, int screenH, int widgetW, int widgetH) {
        int usableW = Math.max(0, screenW - widgetW), usableH = Math.max(0, screenH - widgetH);
        Anchor anchor = anchors.get(element);
        return anchor == null ? new Point(Math.min(element.defaultX, usableW), Math.min(element.defaultY, usableH))
            : new Point((int) Math.round(anchor.x * usableW), (int) Math.round(anchor.y * usableH));
    }
    public void move(Element element, double x, double y, int screenW, int screenH, int widgetW, int widgetH) {
        int usableW = Math.max(0, screenW - widgetW), usableH = Math.max(0, screenH - widgetH);
        restore(element, usableW == 0 ? 0 : x / usableW, usableH == 0 ? 0 : y / usableH);
    }
    public void restore(Element element, double x, double y) {
        if (Double.isFinite(x) && Double.isFinite(y)) anchors.put(element, new Anchor(clamp(x), clamp(y)));
    }
    public Map<Element, Anchor> saved() { return Map.copyOf(anchors); }
    public void reset() { anchors.clear(); }
    private static double clamp(double value) { return Math.max(0, Math.min(1, value)); }
}
