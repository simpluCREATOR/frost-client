package dev.aurora.client.gui;

import dev.aurora.client.AuroraClient;
import dev.aurora.client.module.Module;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

public final class ClickGuiScreen extends Screen {
    private enum Page { MODULES, VISUALS, SETTINGS, HUD }
    private Page page = Page.MODULES;
    private int left, top, panelWidth, panelHeight, bodyY, rowHeight;
    public ClickGuiScreen() { super(Component.literal("POKI Client")); }
    @Override protected void init() {
        panelWidth = Math.min(580, width - 24);
        panelHeight = Math.min(300, height - 24);
        left = (width - panelWidth) / 2; top = (height - panelHeight) / 2;
        bodyY = top + 90;
        rowHeight = Math.min(46, (panelHeight - 140) / 3);
        int tabW = (panelWidth - 48) / 4;
        for (Page target : Page.values()) {
            String name = switch (target) { case MODULES -> "Modules"; case VISUALS -> "Visuals"; case SETTINGS -> "Settings"; case HUD -> "HUD"; };
            addRenderableWidget(new ModernButton(left + 12 + target.ordinal() * (tabW + 8), top + 50,
                tabW, 25, name, () -> "", () -> page == target, false, true, () -> { if (target == Page.HUD) minecraft.setScreen(new HudEditorScreen(this)); else { page = target; rebuildWidgets(); } }));
        }
        addRenderableWidget(new ModernButton(left + panelWidth - 32, top + 12, 20, 20, "×",
            () -> "", () -> false, false, true, this::onClose));
        switch (page) {
            case MODULES -> {
                int columns = panelWidth >= 450 ? 3 : 2;
                int cardW = (panelWidth - 24 - (columns - 1) * 8) / columns;
                int i = 0;
                for (Module module : Module.values()) {
                    String name = switch (module) {
                        case AUTO_SPRINT -> "Auto Sprint"; case ZOOM -> "Zoom"; case FPS -> "FPS Counter";
                        case COORDINATES -> "Coordinates"; case FULLBRIGHT -> "Fullbright"; case KEYSTROKES -> "Keystrokes";
                    };
                    addRenderableWidget(new ModernButton(left + 12 + (i % columns) * (cardW + 8),
                        bodyY + (i++ / columns) * (rowHeight + 8), cardW, rowHeight, name,
                        () -> AuroraClient.modules.enabled(module) ? "ON" : "OFF",
                        () -> AuroraClient.modules.enabled(module), true, false, () -> AuroraClient.modules.toggle(module)));
                }
            }
            case VISUALS -> {
                setting(0, "Fire", () -> AuroraClient.modules.fireMode().label(), () -> false, false, () -> AuroraClient.modules.cycleFire());
                setting(1, "Low Shield", () -> AuroraClient.modules.lowShield() ? "ON" : "OFF",
                    () -> AuroraClient.modules.lowShield(), true, () -> AuroraClient.modules.toggleLowShield());
            }
            case HUD -> { /* Opens the dedicated editor from the HUD tab. */ }
            case SETTINGS -> {
                setting(0, "GUI Scale", this::scaleValue, () -> false, false, this::cycleGuiScale);
                setting(1, "VSync", () -> minecraft.options.enableVsync().get() ? "ON" : "OFF",
                    () -> minecraft.options.enableVsync().get(), true, () -> {
                        minecraft.options.enableVsync().set(!minecraft.options.enableVsync().get()); minecraft.options.save();
                    });
                setting(2, "Dark Mode", () -> AuroraClient.modules.darkMode() ? "ON" : "OFF",
                    () -> AuroraClient.modules.darkMode(), true, () -> AuroraClient.modules.toggleDarkMode());
            }
        }
    }
    private void setting(int row, String name, Supplier<String> value, BooleanSupplier state, boolean toggle, Runnable action) {
        addRenderableWidget(new ModernButton(left + 12, bodyY + row * (rowHeight + 8), panelWidth - 24,
            rowHeight, name, value, state, toggle, false, action));
    }
    private String scaleValue() {
        int scale = minecraft.options.guiScale().get();
        return scale == 0 ? "Auto" : scale + "x";
    }
    private void cycleGuiScale() {
        int max = minecraft.getWindow().calculateScale(0, minecraft.isEnforceUnicode());
        int current = minecraft.options.guiScale().get();
        minecraft.options.guiScale().set(current >= max ? 0 : current + 1);
        minecraft.options.save(); minecraft.resizeDisplay();
    }
    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0xA0080B14);
        UiTheme.round(g, left - 3, top + 4, panelWidth + 6, panelHeight + 4, 14, 0x30000000);
        UiTheme.round(g, left, top, panelWidth, panelHeight, 12, UiTheme.border());
        UiTheme.round(g, left + 1, top + 1, panelWidth - 2, panelHeight - 2, 11, UiTheme.panel());
        UiTheme.round(g, left + 12, top + 12, 26, 26, 7, UiTheme.accentFill());
        g.drawString(font, UiTheme.text("P"), left + 21, top + 20, 0xFFFFFFFF, false);
        g.drawString(font, UiTheme.text("POKI CLIENT"), left + 47, top + 13, UiTheme.text(), false);
        String renderer = FabricLoader.getInstance().isModLoaded("vulkanmod") ? "Vulkan" : "OpenGL";
        g.drawString(font, UiTheme.text(renderer + "  /  1.21.11"), left + 47, top + 27, UiTheme.muted(), false);
        g.fill(left + 12, top + panelHeight - 25, left + panelWidth - 12, top + panelHeight - 24, UiTheme.border());
        String footer = page == Page.VISUALS ? "First-person visuals only" : "Right Shift or Esc to close";
        g.drawString(font, UiTheme.text(footer), left + 14, top + panelHeight - 17, UiTheme.muted(), false);
        var version = UiTheme.text("0.4.0");
        g.drawString(font, version, left + panelWidth - font.width(version) - 14, top + panelHeight - 17, UiTheme.muted(), false);
        super.render(g, mouseX, mouseY, delta);
    }
    @Override public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        return super.keyPressed(event);
    }
    @Override public boolean isPauseScreen() { return false; }
}
