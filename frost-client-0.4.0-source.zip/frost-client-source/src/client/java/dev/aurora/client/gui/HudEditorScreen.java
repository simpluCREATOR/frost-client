package dev.aurora.client.gui;

import dev.aurora.client.AuroraClient;
import dev.aurora.client.hud.ClientHud;
import dev.aurora.client.hud.HudLayout;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Edits the same bounds the HUD renderer uses, in Minecraft's scaled GUI coordinates. */
public final class HudEditorScreen extends Screen {
    private final Screen parent;
    private HudLayout.Element dragging, selected;
    private double offsetX, offsetY;
    public HudEditorScreen(Screen parent) { super(Component.literal("POKI HUD Editor")); this.parent = parent; }
    @Override protected void init() {
        dragging = null;
        addRenderableWidget(new ModernButton(width / 2 - 94, height - 34, 90, 22, "Reset",
            () -> "", () -> false, false, true, this::resetLayout));
        addRenderableWidget(new ModernButton(width / 2 + 4, height - 34, 90, 22, "Done",
            () -> "", () -> true, false, true, this::onClose));
    }
    public void resetLayout() { AuroraClient.modules.hudLayout().reset(); AuroraClient.modules.saveHudLayout(); }
    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0x50080B14);
        g.fill(width / 2, 0, width / 2 + 1, height, 0x307F70D8);
        g.fill(0, height / 2, width, height / 2 + 1, 0x307F70D8);
        for (HudLayout.Element element : HudLayout.Element.values()) {
            var b = ClientHud.bounds(minecraft, element, width, height);
            ClientHud.drawElement(g, minecraft, element, b, true);
            boolean hover = b.contains(mouseX, mouseY);
            int color = element == selected || hover ? UiTheme.accent() : UiTheme.muted();
            g.renderOutline(b.x() - 2, b.y() - 2, b.width() + 4, b.height() + 4, color);
            if (hover || element == selected) {
                String label = element.label + (ClientHud.enabled(element) ? "" : " (OFF preview)");
                g.drawString(font, UiTheme.text(label), b.x(), Math.max(1, b.y() - 12), UiTheme.text(), false);
            }
        }
        var text = UiTheme.text("Drag widgets • Arrow keys nudge • Esc saves");
        int textW = font.width(text);
        UiTheme.round(g, width / 2 - textW / 2 - 8, 8, textW + 16, 20, 6, UiTheme.panel());
        g.drawString(font, text, (width - textW) / 2, 14, UiTheme.text(), false);
        super.render(g, mouseX, mouseY, delta);
    }
    @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        if (event.button() != GLFW.GLFW_MOUSE_BUTTON_LEFT) return false;
        var elements = HudLayout.Element.values();
        for (int i = elements.length - 1; i >= 0; i--) {
            var b = ClientHud.bounds(minecraft, elements[i], width, height);
            if (b.contains(event.x(), event.y())) {
                selected = dragging = elements[i]; offsetX = event.x() - b.x(); offsetY = event.y() - b.y();
                setDragging(true); return true;
            }
        }
        selected = null;
        return false;
    }
    @Override public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging == null) return super.mouseDragged(event, dx, dy);
        var b = ClientHud.bounds(minecraft, dragging, width, height);
        AuroraClient.modules.hudLayout().move(dragging, event.x() - offsetX, event.y() - offsetY,
            width, height, b.width(), b.height());
        return true;
    }
    @Override public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null && event.button() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            dragging = null; setDragging(false); AuroraClient.modules.saveHudLayout(); return true;
        }
        return super.mouseReleased(event);
    }
    @Override public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        if (selected != null && getFocused() == null) {
            int step = (event.modifiers() & GLFW.GLFW_MOD_SHIFT) != 0 ? 10 : 1;
            int dx = switch (event.key()) { case GLFW.GLFW_KEY_LEFT -> -step; case GLFW.GLFW_KEY_RIGHT -> step; default -> 0; };
            int dy = switch (event.key()) { case GLFW.GLFW_KEY_UP -> -step; case GLFW.GLFW_KEY_DOWN -> step; default -> 0; };
            if (dx != 0 || dy != 0) {
                var b = ClientHud.bounds(minecraft, selected, width, height);
                AuroraClient.modules.hudLayout().move(selected, b.x() + dx, b.y() + dy, width, height, b.width(), b.height());
                AuroraClient.modules.saveHudLayout(); return true;
            }
        }
        return super.keyPressed(event);
    }
    @Override public void onClose() { AuroraClient.modules.saveHudLayout(); minecraft.setScreen(parent); }
    @Override public void removed() { AuroraClient.modules.saveHudLayout(); super.removed(); }
    @Override public boolean isPauseScreen() { return false; }
}
