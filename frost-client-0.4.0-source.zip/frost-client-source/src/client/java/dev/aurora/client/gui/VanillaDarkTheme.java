package dev.aurora.client.gui;

import dev.aurora.client.AuroraClient;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

/** Tint UI backgrounds only; item models and world textures retain their colors. */
public final class VanillaDarkTheme {
    private VanillaDarkTheme() {}
    public static boolean active() {
        return AuroraClient.modules != null && AuroraClient.modules.darkMode() && Minecraft.getInstance().screen != null;
    }
    public static int texture(Identifier id, int original) {
        if (!active() || !id.getNamespace().equals("minecraft")) return original;
        String path = id.getPath();
        if (!(path.startsWith("textures/gui/container/") || path.equals("textures/gui/menu_background.png")
            || path.equals("textures/gui/inworld_menu_background.png") || path.equals("textures/gui/options_background.png"))) return original;
        return tint(original);
    }
    public static int sprite(Identifier id, int original) {
        if (!active() || !id.getNamespace().equals("minecraft")) return original;
        String path = id.getPath();
        if (!(path.startsWith("widget/button") || path.startsWith("widget/slider")
            || path.startsWith("widget/text_field") || path.contains("background")
            || path.startsWith("container/creative_inventory/tab_") || path.startsWith("container/creative_inventory/scroller"))) return original;
        return tint(original);
    }
    public static int label(int original) {
        return active() && (original & 0xFFFFFF) == 0x404040 ? 0xFFE2E8F0 : original;
    }
    private static int tint(int original) {
        // Preserve incoming alpha and multiply RGB once, matching vanilla texture modulation.
        int r = ((original >>> 16) & 255) * 88 / 255;
        int g = ((original >>> 8) & 255) * 97 / 255;
        int b = (original & 255) * 116 / 255;
        return (original & 0xFF000000) | (r << 16) | (g << 8) | b;
    }
}
