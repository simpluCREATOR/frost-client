package dev.aurora.client.hud;

import dev.aurora.client.AuroraClient;
import dev.aurora.client.gui.HudEditorScreen;
import dev.aurora.client.gui.UiTheme;
import dev.aurora.client.module.Module;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class ClientHud {
    public record Bounds(int x, int y, int width, int height) {
        public boolean contains(double px, double py) { return px >= x && py >= y && px < x + width && py < y + height; }
    }
    private ClientHud() {}
    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.options.hideGui || client.screen instanceof HudEditorScreen) return;
        for (HudLayout.Element element : HudLayout.Element.values()) {
            if (enabled(element)) drawElement(g, client, element, bounds(client, element, g.guiWidth(), g.guiHeight()), false);
        }
    }
    public static boolean enabled(HudLayout.Element element) {
        return AuroraClient.modules.enabled(switch (element) {
            case FPS -> Module.FPS; case COORDINATES -> Module.COORDINATES; case KEYSTROKES -> Module.KEYSTROKES;
        });
    }
    private static String label(Minecraft client, HudLayout.Element element) {
        if (element == HudLayout.Element.FPS) return client.getFps() + " FPS";
        if (client.player == null) return "XYZ 120 / 64 / -320";
        var pos = client.player.blockPosition();
        return "XYZ " + pos.getX() + " / " + pos.getY() + " / " + pos.getZ();
    }
    public static Bounds bounds(Minecraft client, HudLayout.Element element, int screenW, int screenH) {
        int w = element == HudLayout.Element.KEYSTROKES ? 100
            : Math.max(element == HudLayout.Element.FPS ? 52 : 136, client.font.width(UiTheme.text(label(client, element))) + 10);
        int h = element == HudLayout.Element.KEYSTROKES ? 96 : 14;
        var point = AuroraClient.modules.hudLayout().position(element, screenW, screenH, w, h);
        return new Bounds(point.x(), point.y(), w, h);
    }
    public static void drawElement(GuiGraphics g, Minecraft client, HudLayout.Element element, Bounds b, boolean preview) {
        if (element != HudLayout.Element.KEYSTROKES) {
            UiTheme.round(g, b.x, b.y, b.width, b.height, 4, UiTheme.hud());
            g.drawString(client.font, UiTheme.text(label(client, element)), b.x + 5, b.y + 3, UiTheme.text(), false);
            return;
        }
        int x = b.x, y = b.y;
        key(g, client, x + 34, y, 32, 24, "W", !preview && client.options.keyUp.isDown());
        key(g, client, x, y + 26, 32, 24, "A", !preview && client.options.keyLeft.isDown());
        key(g, client, x + 34, y + 26, 32, 24, "S", !preview && client.options.keyDown.isDown());
        key(g, client, x + 68, y + 26, 32, 24, "D", !preview && client.options.keyRight.isDown());
        key(g, client, x, y + 52, 49, 24, "LMB", !preview && client.options.keyAttack.isDown());
        key(g, client, x + 51, y + 52, 49, 24, "RMB", !preview && client.options.keyUse.isDown());
        boolean jump = !preview && client.options.keyJump.isDown();
        key(g, client, x, y + 78, 100, 18, "", jump);
        int color = jump ? 0xFFFFFFFF : UiTheme.text();
        g.fill(x + 41, y + 85, x + 42, y + 90, color);
        g.fill(x + 41, y + 89, x + 59, y + 90, color);
        g.fill(x + 58, y + 85, x + 59, y + 90, color);
    }
    private static void key(GuiGraphics g, Minecraft client, int x, int y, int w, int h, String label, boolean down) {
        UiTheme.round(g, x, y, w, h, 4, down ? UiTheme.accentFill() : UiTheme.hud());
        var text = UiTheme.text(label);
        g.drawString(client.font, text, x + (w - client.font.width(text)) / 2, y + (h - 9) / 2,
            down ? 0xFFFFFFFF : UiTheme.text(), false);
    }
}
