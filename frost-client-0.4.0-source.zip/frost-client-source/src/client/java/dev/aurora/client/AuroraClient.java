package dev.aurora.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.aurora.client.gui.ClickGuiScreen;
import dev.aurora.client.hud.ClientHud;
import dev.aurora.client.module.Module;
import dev.aurora.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class AuroraClient implements ClientModInitializer {
    public static ModuleManager modules;
    private static KeyMapping zoom;
    private KeyMapping menu;

    @Override public void onInitializeClient() {
        modules = new ModuleManager();
        var category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("aurora", "client"));
        menu = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.aurora.menu",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        zoom = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.aurora.zoom",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, category));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menu.consumeClick()) {
                if (client.screen == null) client.setScreen(new ClickGuiScreen());
            }
            // Ask vanilla to sprint; vanilla retains hunger, collision and movement rules.
            if (client.player != null && client.screen == null && modules.enabled(Module.AUTO_SPRINT)) {
                if (client.options.keyUp.isDown() && !client.player.isShiftKeyDown()
                    && !client.player.isUsingItem() && !client.player.horizontalCollision
                    && (client.player.getFoodData().getFoodLevel() > 6 || client.player.getAbilities().mayfly)) {
                    client.player.setSprinting(true);
                }
            }
        });
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
            Identifier.fromNamespaceAndPath("aurora", "hud"), ClientHud::render);
    }
    public static boolean zoomActive() {
        var client = Minecraft.getInstance();
        return modules != null && modules.enabled(Module.ZOOM) && zoom != null && zoom.isDown()
            && client.screen == null && client.player != null;
    }
}
