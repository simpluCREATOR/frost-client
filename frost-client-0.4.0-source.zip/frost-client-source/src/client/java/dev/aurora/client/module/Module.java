package dev.aurora.client.module;

/** Stable config IDs are separate from display names. */
public enum Module {
    AUTO_SPRINT("auto_sprint", "Auto Sprint", false),
    ZOOM("zoom", "Zoom (hold C)", true),
    FPS("fps", "FPS Counter", true),
    COORDINATES("coordinates", "Coordinates HUD", true),
    FULLBRIGHT("fullbright", "Fullbright", false),
    KEYSTROKES("keystrokes", "Keystrokes", true);

    public final String id;
    public final String label;
    public final boolean defaultEnabled;
    Module(String id, String label, boolean defaultEnabled) {
        this.id = id;
        this.label = label;
        this.defaultEnabled = defaultEnabled;
    }
}
