package dev.aurora.client.module;

import com.google.gson.*;
import dev.aurora.client.hud.HudLayout;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Reads the original flat config and keeps existing module IDs intact. */
public final class ModuleManager {
    public enum FireMode { DEFAULT, LOW, NONE;
        public String label() { return switch (this) { case DEFAULT -> "Default"; case LOW -> "Low"; case NONE -> "None"; }; }
    }
    private final EnumMap<Module, Boolean> enabled = new EnumMap<>(Module.class);
    private final Path path = FabricLoader.getInstance().getConfigDir().resolve("aurora.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private FireMode fireMode = FireMode.LOW;
    private boolean lowShield = false;
    private boolean darkMode = true;
    private final HudLayout hudLayout = new HudLayout();

    public ModuleManager() {
        for (Module module : Module.values()) enabled.put(module, module.defaultEnabled);
        if (Files.exists(path)) {
            try (var reader = Files.newBufferedReader(path)) {
                JsonObject saved = JsonParser.parseReader(reader).getAsJsonObject();
                for (Module module : Module.values()) enabled.put(module, bool(saved, module.id, module.defaultEnabled));
                if (saved.has("hud_positions") && saved.get("hud_positions").isJsonObject()) {
                    JsonObject positions = saved.getAsJsonObject("hud_positions");
                    for (HudLayout.Element element : HudLayout.Element.values()) {
                        try {
                            if (!positions.has(element.id) || !positions.get(element.id).isJsonObject()) continue;
                            JsonObject pos = positions.getAsJsonObject(element.id);
                            hudLayout.restore(element, pos.get("x").getAsDouble(), pos.get("y").getAsDouble());
                        } catch (RuntimeException ignored) { /* Ignore only the invalid widget position. */ }
                    }
                }
                lowShield = bool(saved, "low_shield", false);
                darkMode = bool(saved, "dark_mode", true);
                if (saved.has("fire") && saved.get("fire").isJsonPrimitive()
                    && saved.getAsJsonPrimitive("fire").isString()) {
                    try { fireMode = FireMode.valueOf(saved.get("fire").getAsString().toUpperCase(Locale.ROOT)); }
                    catch (IllegalArgumentException ignored) { /* Keep the safe default for unknown modes. */ }
                }
            } catch (IOException | RuntimeException error) {
                LoggerFactory.getLogger("aurora").warn("Cannot load POKI settings; using defaults", error);
            }
        }
    }
    private static boolean bool(JsonObject object, String key, boolean fallback) {
        JsonElement value = object.get(key);
        return value != null && value.isJsonPrimitive() && value.getAsJsonPrimitive().isBoolean()
            ? value.getAsBoolean() : fallback;
    }
    public HudLayout hudLayout() { return hudLayout; }
    public void saveHudLayout() { save(); }
    public boolean enabled(Module module) { return enabled.get(module); }
    public FireMode fireMode() { return fireMode; }
    public boolean lowShield() { return lowShield; }
    public boolean darkMode() { return darkMode; }
    public void toggle(Module module) { enabled.put(module, !enabled(module)); save(); }
    public void cycleFire() { fireMode = FireMode.values()[(fireMode.ordinal() + 1) % FireMode.values().length]; save(); }
    public void toggleLowShield() { lowShield = !lowShield; save(); }
    public void toggleDarkMode() { darkMode = !darkMode; save(); }
    private void save() {
        JsonObject saved = new JsonObject();
        for (Module module : Module.values()) saved.addProperty(module.id, enabled(module));
        saved.addProperty("fire", fireMode.name().toLowerCase(Locale.ROOT));
        saved.addProperty("low_shield", lowShield);
        saved.addProperty("dark_mode", darkMode);
        JsonObject positions = new JsonObject();
        hudLayout.saved().forEach((element, anchor) -> {
            JsonObject pos = new JsonObject(); pos.addProperty("x", anchor.x()); pos.addProperty("y", anchor.y());
            positions.add(element.id, pos);
        });
        saved.add("hud_positions", positions);
        try {
            Files.createDirectories(path.getParent());
            Path temporary = path.resolveSibling("aurora.json.tmp");
            Files.writeString(temporary, GSON.toJson(saved));
            try { Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ignored) { Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException error) { LoggerFactory.getLogger("aurora").warn("Cannot save POKI settings", error); }
    }
}
