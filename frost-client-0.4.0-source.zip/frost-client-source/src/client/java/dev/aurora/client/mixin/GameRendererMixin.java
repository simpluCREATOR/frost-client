package dev.aurora.client.mixin;

import dev.aurora.client.AuroraClient;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void aurora$zoom(CallbackInfoReturnable<Float> cir) {
        if (AuroraClient.zoomActive()) cir.setReturnValue(cir.getReturnValue() / 4.0F);
    }
}
