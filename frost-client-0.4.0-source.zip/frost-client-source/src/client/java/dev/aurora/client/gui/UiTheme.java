package dev.aurora.client.gui;

import dev.aurora.client.AuroraClient;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.resources.Identifier;

/** All primitives use Minecraft's renderer-neutral GUI API, including Vulkan. */
public final class UiTheme {
    private static final FontDescription UI_FONT = new FontDescription.Resource(Identifier.fromNamespaceAndPath("aurora", "ui"));
    private UiTheme() {}
    public static boolean dark() { return AuroraClient.modules == null || AuroraClient.modules.darkMode(); }
    public static int panel() { return dark() ? 0xFA141923 : 0xFAF4F5FA; }
    public static int card() { return dark() ? 0xFF1E2634 : 0xFFFFFFFF; }
    public static int hover() { return dark() ? 0xFF293346 : 0xFFECEAFB; }
    public static int border() { return dark() ? 0xFF344054 : 0xFFDADEEA; }
    public static int text() { return dark() ? 0xFFF1F3FB : 0xFF22283B; }
    public static int muted() { return dark() ? 0xFFA1ADC2 : 0xFF687188; }
    public static int accent() { return dark() ? 0xFFA59BFF : 0xFF7356D9; }
    public static int accentFill() { return dark() ? 0xFF6551BF : 0xFF7356D9; }
    public static int hud() { return dark() ? 0xDD141923 : 0xE8F5F6FC; }
    public static Component text(String text) { return Component.literal(text).withStyle(s -> s.withFont(UI_FONT)); }
    public static void round(GuiGraphics g, int x, int y, int w, int h, int radius, int color) {
        int r = Math.min(radius, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, color); return; }
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int row = 0; row < r; row++) {
            double dy = r - row - 0.5;
            int inset = (int) Math.ceil(r - Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + row, x + w - inset, y + row + 1, color);
            g.fill(x + inset, y + h - row - 1, x + w - inset, y + h - row, color);
        }
    }
}
