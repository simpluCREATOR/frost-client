package dev.aurora.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.aurora.client.AuroraClient;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Balanced outer pose affects only the shield in the currently rendered hand. */
@Mixin(ItemInHandRenderer.class)
public abstract class ItemInHandRendererMixin {
    @Inject(method = "renderArmWithItem", at = @At("HEAD"))
    private void poki$lowerShield(AbstractClientPlayer player, float partialTick, float pitch, InteractionHand hand,
        float swing, ItemStack stack, float equip, PoseStack pose, SubmitNodeCollector nodes, int light, CallbackInfo ci) {
        if (poki$lower(stack)) { pose.pushPose(); pose.translate(0.0F, -0.28F, 0.0F); }
    }
    @Inject(method = "renderArmWithItem", at = @At("RETURN"))
    private void poki$restoreShieldPose(AbstractClientPlayer player, float partialTick, float pitch, InteractionHand hand,
        float swing, ItemStack stack, float equip, PoseStack pose, SubmitNodeCollector nodes, int light, CallbackInfo ci) {
        if (poki$lower(stack)) pose.popPose();
    }
    private static boolean poki$lower(ItemStack stack) {
        return AuroraClient.modules != null && AuroraClient.modules.lowShield() && stack.is(Items.SHIELD);
    }
}
