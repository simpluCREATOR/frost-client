package dev.aurora.client.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import dev.aurora.client.gui.VanillaDarkTheme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** The sprite entry point retains its ID before it becomes a region of the shared GUI atlas. */
@Mixin(GuiGraphics.class)
public abstract class GuiGraphicsMixin {
    @ModifyVariable(method = "blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIIII)V",
        at = @At("HEAD"), argsOnly = true, ordinal = 4)
    private int poki$darkWidgets(int color, RenderPipeline pipeline, Identifier id, int x, int y, int width, int height, int inputColor) {
        return VanillaDarkTheme.sprite(id, color);
    }
    @ModifyVariable(method = "innerBlit(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIIIFFFFI)V",
        at = @At("HEAD"), argsOnly = true, ordinal = 4)
    private int poki$darkContainers(int color, RenderPipeline pipeline, Identifier texture, int x0, int x1, int y0, int y1,
        float u0, float u1, float v0, float v1, int inputColor) {
        return VanillaDarkTheme.texture(texture, color);
    }
    @ModifyVariable(method = {
        "drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V",
        "drawString(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)V",
        "drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;IIIZ)V"
    }, at = @At("HEAD"), argsOnly = true, ordinal = 2)
    private int poki$readableLabels(int color) { return VanillaDarkTheme.label(color); }
}
