package dev.aurora.regression;

import dev.aurora.client.AuroraClient;
import dev.aurora.client.gui.*;
import dev.aurora.client.hud.*;
import dev.aurora.client.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.render.state.*;
import net.minecraft.client.input.*;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.LoggerFactory;
import java.util.*;
import java.util.function.Consumer;

/** Uses real GuiGraphics render states and widget event handlers; no OS input is sent. */
public final class UiRegression {
    private static final Identifier INVENTORY = Identifier.withDefaultNamespace("textures/gui/container/inventory.png");
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void verify(Minecraft client) throws Exception {
        var settings = AuroraClient.modules;
        var savedLayout = settings.hudLayout().saved();
        boolean savedDark = settings.darkMode();
        var savedScreen = client.screen;
        try {
            if (!settings.darkMode()) settings.toggleDarkMode();
            GuiRenderState state = new GuiRenderState();
            GuiGraphics graphics = new GuiGraphics(client, state, 0, 0);
            var inventoryBlit = (Consumer<GuiGraphics>) g -> g.blit(RenderPipelines.GUI_TEXTURED, INVENTORY,
                10, 10, 0F, 0F, 176, 166, 256, 256);
            assertBlit(state, graphics, inventoryBlit, 0xFF586174, "dark inventory background");
            assertBlit(state, graphics, g -> g.blitSprite(RenderPipelines.GUI_TEXTURED,
                Identifier.withDefaultNamespace("widget/button"), 10, 10, 150, 20), 0xFF586174, "dark pause/options button, tinted once");
            assertBlit(state, graphics, g -> g.blitSprite(RenderPipelines.GUI_TEXTURED,
                Identifier.withDefaultNamespace("container/creative_inventory/tab_top_selected_0"), 10, 10, 26, 32),
                0xFF586174, "dark creative inventory tab");
            assertBlit(state, graphics, g -> g.blit(RenderPipelines.GUI_TEXTURED,
                Identifier.withDefaultNamespace("textures/atlas/items.png"), 10, 10, 0F, 0F, 16, 16, 1024, 1024),
                0xFFFFFFFF, "item atlas colors unchanged");
            state.reset(); graphics.drawString(client.font, "Inventory", 10, 10, 0x404040, false);
            var colorField = GuiTextRenderState.class.getDeclaredField("color"); colorField.setAccessible(true);
            int[] labels = {0};
            state.forEachText(text -> {
                try { check((colorField.getInt(text) & 0xFFFFFF) == 0xE2E8F0, "dark inventory label is readable"); labels[0]++; }
                catch (IllegalAccessException ex) { throw new AssertionError(ex); }
            });
            check(labels[0] > 0, "inventory label render was recorded");
            settings.toggleDarkMode();
            assertBlit(state, graphics, inventoryBlit, 0xFFFFFFFF, "turning dark mode off restores inventory");
            assertBlit(state, graphics, g -> g.blitSprite(RenderPipelines.GUI_TEXTURED,
                Identifier.withDefaultNamespace("widget/button"), 10, 10, 150, 20), 0xFFFFFFFF, "turning dark mode off restores buttons");

            // Enter the HUD editor through the real menu control.
            ClickGuiScreen menu = new ClickGuiScreen(); client.setScreen(menu);
            Button hud = menu.children().stream().filter(c -> c instanceof Button b && b.getMessage().getString().equals("HUD"))
                .map(c -> (Button)c).findFirst().orElseThrow();
            hud.onPress(new KeyEvent(GLFW.GLFW_KEY_ENTER, 0, 0));
            check(client.screen instanceof HudEditorScreen, "HUD tab opens the editor");
            HudEditorScreen editor = (HudEditorScreen)client.screen;
            int w = editor.width, h = editor.height;
            editor.resetLayout();
            int i = 0;
            for (HudLayout.Element element : HudLayout.Element.values()) {
                var before = ClientHud.bounds(client, element, w, h);
                double fromX = before.x() + 5, fromY = before.y() + 5;
                check(editor.mouseClicked(mouse(fromX, fromY), false), "select " + element);
                int toX = Math.min(w - before.width(), 145 + i * 15), toY = Math.min(h - before.height() - 40, 65 + i * 35);
                check(editor.mouseDragged(mouse(toX + 5, toY + 5), toX - fromX, toY - fromY), "drag " + element);
                check(editor.mouseReleased(mouse(toX + 5, toY + 5)), "release " + element);
                var moved = ClientHud.bounds(client, element, w, h);
                check(moved.x() == toX && moved.y() == toY, "renderer uses dragged position for " + element);
                i++;
            }
            check(new ModuleManager().hudLayout().saved().equals(settings.hudLayout().saved()), "dragged positions survive config reload");
            var keys = ClientHud.bounds(client, HudLayout.Element.KEYSTROKES, w, h);
            editor.mouseClicked(mouse(keys.x() + 5, keys.y() + 5), false);
            editor.mouseDragged(mouse(w + 500, h + 500), 500, 500);
            editor.mouseReleased(mouse(w + 500, h + 500));
            keys = ClientHud.bounds(client, HudLayout.Element.KEYSTROKES, w, h);
            check(keys.x() == w - keys.width() && keys.y() == h - keys.height(), "drag clamps to screen edge");
            var resized = settings.hudLayout().position(HudLayout.Element.KEYSTROKES, 180, 140, 100, 96);
            check(resized.x() == 80 && resized.y() == 44, "position remains visible after resize");
            int oldX = keys.x();
            editor.keyPressed(new KeyEvent(GLFW.GLFW_KEY_LEFT, 0, GLFW.GLFW_MOD_SHIFT));
            check(ClientHud.bounds(client, HudLayout.Element.KEYSTROKES, w, h).x() == Math.max(0, oldX - 10), "Shift-arrow nudges ten pixels");
            state.reset(); editor.render(graphics, 0, 0, 0);
            editor.resetLayout(); check(settings.hudLayout().saved().isEmpty(), "Reset restores defaults");
            LoggerFactory.getLogger("poki-regression").info("POKI_UI_REGRESSION_PASSED: real dark inventory/button/tab blits, readable labels, light-mode restore, item-color preservation; HUD-tab navigation, three drags, reload, clamp, resize, nudge, preview and Reset");
        } finally {
            client.setScreen(savedScreen);
            settings.hudLayout().reset(); savedLayout.forEach((element, point) -> settings.hudLayout().restore(element, point.x(), point.y()));
            if (settings.darkMode() != savedDark) settings.toggleDarkMode();
            settings.saveHudLayout();
        }
    }
    private static MouseButtonEvent mouse(double x, double y) { return new MouseButtonEvent(x, y, new MouseButtonInfo(GLFW.GLFW_MOUSE_BUTTON_LEFT, 0)); }
    private static void assertBlit(GuiRenderState state, GuiGraphics g, Consumer<GuiGraphics> draw, int expected, String message) {
        state.reset(); draw.accept(g); int[] count = {0};
        state.forEachElement(element -> {
            if (element instanceof BlitRenderState blit) { check(blit.color() == expected, message + ": got " + Integer.toHexString(blit.color())); count[0]++; }
        }, GuiRenderState.TraverseRange.ALL);
        check(count[0] > 0, message + " emitted a blit");
    }
}
