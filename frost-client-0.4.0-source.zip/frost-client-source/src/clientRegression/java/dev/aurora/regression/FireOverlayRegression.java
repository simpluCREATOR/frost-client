package dev.aurora.regression;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.aurora.client.AuroraClient;
import dev.aurora.client.module.ModuleManager.FireMode;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.Material;
import net.minecraft.resources.Identifier;
import org.slf4j.LoggerFactory;
import java.lang.reflect.*;
import java.util.*;

/** Runs the real, mixin-transformed renderFire method after real atlas loading. */
public final class FireOverlayRegression implements ClientModInitializer {
    private boolean finished;
    @Override public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (finished || client.getOverlay() != null) return;
            finished = true;
            try { verify(client); UiRegression.verify(client); }
            catch (Throwable error) {
                LoggerFactory.getLogger("poki-regression").error("POKI_REGRESSION_FAILED", error);
                throw new AssertionError("Fire regression failed", error);
            }
            client.stop();
        });
    }
    private static void verify(Minecraft client) throws Exception {
        var manager = client.getAtlasManager();
        var id = Identifier.fromNamespaceAndPath("aurora", "block/low_fire_1");
        var low = manager.get(new Material(TextureAtlas.LOCATION_BLOCKS, id));
        check(id.equals(low.contents().name()), "bundled low-fire sprite was stitched");
        var original = manager.get(new Material(TextureAtlas.LOCATION_BLOCKS,
            Identifier.withDefaultNamespace("block/fire_1")));
        check(!original.contents().name().equals(low.contents().name()), "vanilla and low-fire sprites differ");
        // Reproduce the old failure so the test proves it exercised the incompatible API.
        boolean oldLookupFailed = false;
        try { manager.getAtlasOrThrow(TextureAtlas.LOCATION_BLOCKS); }
        catch (IllegalArgumentException expected) { oldLookupFailed = true; }
        check(oldLookupFailed, "old texture-path lookup reproduces Invalid atlas id");
        Method render = ScreenEffectRenderer.class.getDeclaredMethod("renderFire", PoseStack.class,
            MultiBufferSource.class, TextureAtlasSprite.class);
        render.setAccessible(true);
        FireMode saved = AuroraClient.modules.fireMode();
        int cases = 0;
        try {
            for (int round = 0; round < 30; round++) {
                for (FireMode mode : FireMode.values()) {
                    setMode(mode);
                    var uvs = new ArrayList<float[]>();
                    int[] requests = {0};
                    VertexConsumer vertices = (VertexConsumer) Proxy.newProxyInstance(VertexConsumer.class.getClassLoader(),
                        new Class<?>[]{VertexConsumer.class}, (proxy, method, args) -> {
                            if (method.getName().equals("setUv")) uvs.add(new float[]{(float) args[0], (float) args[1]});
                            return method.getReturnType() == VertexConsumer.class ? proxy : null;
                        });
                    MultiBufferSource buffers = type -> { requests[0]++; return vertices; };
                    PoseStack pose = new PoseStack();
                    render.invoke(null, pose, buffers, original);
                    if (mode == FireMode.NONE) {
                        check(requests[0] == 0 && uvs.isEmpty(), "None cancels before requesting geometry");
                    } else {
                        check(requests[0] == 1 && uvs.size() == 8, mode + " emits both fire quads");
                        var expected = mode == FireMode.LOW ? low : original;
                        for (float[] uv : uvs) {
                            check(close(uv[0], expected.getU0()) || close(uv[0], expected.getU1()), mode + " uses expected sprite U");
                            check(close(uv[1], expected.getV0()) || close(uv[1], expected.getV1()), mode + " uses expected sprite V");
                        }
                    }
                    cases++;
                }
            }
        } finally { setMode(saved); }
        LoggerFactory.getLogger("poki-regression").info(
            "POKI_FIRE_REGRESSION_PASSED: {} real renderFire calls; Default/Low/None cycling; UVs correct; old atlas failure reproduced", cases);
    }
    private static boolean close(float a, float b) { return Math.abs(a - b) < 0.00001F; }
    private static void setMode(FireMode mode) {
        while (AuroraClient.modules.fireMode() != mode) AuroraClient.modules.cycleFire();
    }
    private static void check(boolean success, String detail) { if (!success) throw new AssertionError(detail); }
}
