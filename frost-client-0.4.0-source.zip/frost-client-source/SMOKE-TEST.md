# POKI 0.4.0 in-game acceptance checks

Real Minecraft integration tests passed on Vulkan and OpenGL for targeted dark UI blits, readable inventory labels, original colors when Dark Mode is OFF, preserved item atlas colors, actual HUD-tab event routing, all three drag handlers, saved-position reload, clamping, resize behavior, keyboard nudge, preview rendering and Reset. The previous fire regression also passed on both renderers. These automated checks inspect actual rendering states/event handlers; they are not pixel screenshot comparisons.

Manual checks in your usual profile:

1. Toggle Dark Mode under Right Shift → Settings. Open Escape/Options, survival inventory, creative inventory and a chest. Check panel/button backgrounds are dark and labels remain readable. Toggle OFF and confirm original colors return. Check your resource pack too.
2. Open Right Shift → HUD. Drag FPS, Coordinates and Keystrokes to different places; click Done and close the menu. Confirm the gameplay HUD matches the preview positions.
3. Restart and confirm positions persist. Change resolution, window size and GUI Scale; confirm elements remain visible. Use Reset to restore default placement.
4. Disable a HUD module and open the editor. It should appear as an OFF preview; moving it must not enable it. Enable it later and confirm it uses the saved location.
5. Click a widget and nudge with arrows or Shift-arrows. Close with Escape or Right Shift, or switch screens while dragging, and confirm the last position is kept.
6. Check keystroke highlights and the longer spacebar below LMB/RMB, F1 hiding the HUD, C zoom release, Low Shield and Fire mode selection in a world.
7. Install only one POKI version/edition. Keep Fabric API. For Vulkan, exclude Sodium/Iris and a separate VulkanMod copy. Third-party UI skins may use their own colors.
