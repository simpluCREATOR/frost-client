#!/bin/sh
# Use native Java 21, without changing the system-wide Java installation.
set -eu
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
LOCAL_JDK="$PROJECT_DIR/../../work/jdk-21.0.13+9/Contents/Home"
if [ -x "$LOCAL_JDK/bin/java" ]; then
    JAVA_HOME="$LOCAL_JDK"
else
    JAVA_HOME=$(/usr/libexec/java_home -v 21 -a arm64)
fi
export JAVA_HOME
# Keep the build cache within this workspace in the supplied layout.
if [ -d "$PROJECT_DIR/../../work/gradle-home" ]; then
    GRADLE_USER_HOME="$PROJECT_DIR/../../work/gradle-home"
    export GRADLE_USER_HOME
fi
cd "$PROJECT_DIR"
if [ "$#" -eq 0 ]; then set -- build; fi
exec ./gradlew "$@"
