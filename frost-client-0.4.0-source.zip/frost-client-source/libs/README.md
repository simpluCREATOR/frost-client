# Optional Vulkan build dependency

The source upload deliberately omits the third-party renderer binary.
Build the Frost/OpenGL release without it:

    ./gradlew build -PbundleVulkan=false

For the optional Vulkan edition, obtain the original VulkanMod 0.6.8+1.21.11 JAR from https://modrinth.com/mod/vulkanmod/version/hWKRTXbQ and place it here as VulkanMod-0.6.8+1.21.11.jar. Verify SHA-512:

cbc25c9baee5e3d0e187476ce0b461a5b278341140df9764f4032d1186d8eab8607680480ce09f63887772a7547626d57b11b6a8a90bd5f53de0196bbfc573bb

VulkanMod is LGPL-3.0-only. Retain its notices, supply the applicable GPL and LGPL texts, and establish corresponding source for the exact release before redistributing a bundled Vulkan binary. The existing upstream dev-branch link alone does not pin that source revision. See THIRD-PARTY-NOTICES.md.
